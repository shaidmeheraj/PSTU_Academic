/*
 Write a Java program to print 'Hello' on screen and then print your name on a separate line. Go to the editor
 :
Hello
Alexandra Abramov
 */
package CCE;

/**
 *
 * @author shaid
 */
public class JavaPrograms {
    public static void main(String[] args){
        System.out.println("Hello");
        System.out.println("Alexandra Abramov");
    }
}
