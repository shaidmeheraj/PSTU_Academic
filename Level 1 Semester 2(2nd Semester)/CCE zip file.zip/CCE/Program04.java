/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CCE;

/**
 *
 * @author shaid
 */
public class Program04 {
    public static void main(String[] args){
        System.out.println("a. "+ (-5 + 8 * 6));
        System.out.println("b. "+ (55+9)%9);
        System.out.println("c. "+ (20 + (-3*5)/8));
        System.out.println("a. "+ (5+15/3*2-8%3));
    }
}
