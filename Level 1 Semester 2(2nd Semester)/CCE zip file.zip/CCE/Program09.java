/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CCE;

public class Program09 {
    public static void main(String[] args){
        System.out.println((25.5 * 3.5 - 3.5 * 3.5)/(40.5 - 4.5));
    }
}
