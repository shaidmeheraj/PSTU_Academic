/*
 * Write a Java program to check whether a given integer is a power of 4 or not. Go to the editor
Given num = 64, return true. Given num = 6, return false.
Click me to see the solution
 */

import java.util.Scanner;

public class Pbm_110 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Given number: ");
        int n = in.nextInt();
        

        if (n == 0) {
            System.out.println();
            return;
        }

        while (n != 1) {
            if (n % 4 != 0) {
                System.out.println();
                return;
            }
            n = n / 4;
        }

        System.out.println();
    }
}
