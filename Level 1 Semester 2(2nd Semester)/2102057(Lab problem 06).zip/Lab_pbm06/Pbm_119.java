/*
 * Write a Java program to get the first 
 * occurrence (Position starts from 0.)
 *  of an element of a given array.
 */
public class Pbm_119 {
    public static void main(String[] args) {
        int nums[] = { 2, 4, 6, 7, 8 };
        int target = 7;
        int lower = 0;
        int upper = nums.length - 1;
        int index = -1;
        while (lower <= upper) {
            int mid = (lower + upper) >> 1;
            if (nums[mid] == target) {
                index = mid;
            }
            if (nums[mid] >= target) {
                upper = mid - 1;
            } else {
                lower = mid + 1;
            }
        }
        System.out.print("Position of " + target + " is " + index);
    }
}
