/*
 * Write a Java program to check 
 * if a specified array of integers contains 10 or 30
 */

import java.util.Arrays;

public class Pbm_102 {
    public static void main(String[] args) {
        int[] array_num = {11,11,13,31,45,20,33,53};
        int r = 1;
        System.out.println("Original Array: "+Arrays.toString(array_num));

        for(int i = 0;i<array_num.length;i++){
            if (array_num[i]==10 || array_num[i]==30) {
                r = 0;
            }
        }
        if(r==1)
          System.out.println(String.valueOf(false));
        else
          System.out.println(String.valueOf(true));  
    }
}
