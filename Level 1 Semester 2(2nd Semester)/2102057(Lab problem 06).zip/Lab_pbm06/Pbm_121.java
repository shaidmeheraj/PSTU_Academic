/*
 * Write a Java program to reverse a given linked list. Go to the editor
Example: For linked list 20->40->60->80, the reversed linked list is 80->60->40->20 
 */
public class Pbm_121 {
    
}
