/*
 * Write a Java program to check if the number of 10 
 * is greater than number to 20 in a given array of integers
 */
public class Pbm_101 {
    
}