/*
 * Write a Java program to create a new array from 
 * a given array of integers, 
 * new array will contain the elements from 
 * the given array after the last element value 10.
 */

import java.util.Arrays;

public class Pbm_103 {
    public static void main(String[] args) {
        int[] array_num = {11,10,13,100,45,20,33,53};
        int r = 0;
        System.out.println("Original Array: "+Arrays.toString(array_num));

        int l = array_num.length-1;
        int[] new_array;
        while(array_num[l]!=10)
        l--;
        new_array = new int[array_num.length-1-l];
        for(int i = l+1;i<array_num.length;i++)
            new_array[i-l-1] = array_num[i];
        System.out.println("New Array: "+Arrays.toString(new_array));    
    }
}
