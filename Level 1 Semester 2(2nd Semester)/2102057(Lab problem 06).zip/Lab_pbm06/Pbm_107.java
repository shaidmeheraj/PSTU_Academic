/*
 * Write a Java program to check if an array 
 * of integers contains three increasing adjacent numbers. 
 */

import java.util.Arrays;

public class Pbm_107 {
    public static void main(String[] args) {
        int[] array_num = {11,12,13,14,45,20};
        System.out.println("Original Array: "+Arrays.toString(array_num));
        int r = 1;

        for(int i=0;i<=array_num.length-3;i++){
            if(array_num[i]+1 == array_num[i+1] && array_num[i+1]+1 == array_num[i+2])
            r=0;
        }

        if (r==1) {
            System.out.println(String.valueOf(false));
        }
        else
        {
            System.out.println(String.valueOf(true));
        }
    }
}
