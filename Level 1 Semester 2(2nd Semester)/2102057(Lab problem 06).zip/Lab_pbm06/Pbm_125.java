/*
 * Write a Java program to get the preorder traversal of its nodes' values of a given a binary tree. Go to the editor
Example:
    10
   / \
  20   30
 / \
40   50
Expected output: 10 20 40 50 30
 */
public class Pbm_125 {
    
}
