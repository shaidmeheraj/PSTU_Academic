/*
 * Write a Java program to add all the digits of a given
 *  positive integer until the result has a single digit. 
 */

import java.util.Scanner;

public class Pbm_108 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Input a positive number: ");
        int n = in.nextInt();
        if (n>0) {
            System.out.println("The single digit number is: "+(n==0?0:(n%9==0?9:n%9)));
        }
        System.out.println("\n");
    }
}
