/*
 * Write a Java program to extract the first half of a string of even length. Go to the editor

Test Data: Python



Pyt
 */
public class Pbm_19 {
    public static void main(String[] args) {
        String main_String = "Python";
        System.out.println(main_String.substring(0, 3));
    }
}
